public class FestivalPlanningException extends Exception {

    public FestivalPlanningException(String message) {
        super(message);
    }

    public FestivalPlanningException(String message, Throwable cause) {
        super(message, cause);
    }
}
