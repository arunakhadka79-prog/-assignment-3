import java.util.ArrayList;
import java.util.List;

public class DashainFestivalPlanner {

    public static void executeFestivalPlan(List<FestivalActivity> activities) {
        for (FestivalActivity activity : activities) {
            activity.displayOverview();
            try {
                activity.planActivity();
            } catch (InvalidGuestCountException e) {
                System.out.println("Planning Warning (Guests): " + e.getMessage());
            } catch (BudgetExceededException e) {
                System.out.println("Planning Warning (Budget): " + e.getMessage());
            } catch (NoRouteException e) {
                System.out.println("Planning Warning (Routes): " + e.getMessage());
            } catch (FestivalPlanningException e) {
                System.out.println("General Planning Error: " + e.getMessage());
            } finally {
                System.out.println("Activity planning attempt for " + activity.activityName + " completed.");
            }
            System.out.println("=====================================");
        }
    }

    public static void main(String[] args) {
        List<FestivalActivity> activities = new ArrayList<>();

        activities.add(new TikaCeremony("Tika Ceremony", 30000, 12, "Grandmother Maya"));
        activities.add(new TikaCeremony("Tika Ceremony", 15000, 3, "Uncle Krishna"));
        activities.add(new TikaCeremony("Tika Ceremony", 60000, 10, "Aunt Gita"));

        activities.add(new DeusiBhailo("Deusi Bhailo Program", 12000,
                List.of("Thamel", "Ason", "Indrachowk"), 8));
        activities.add(new DeusiBhailo("Deusi Bhailo Program", 9000, List.of(), 4));
        activities.add(new DeusiBhailo("Deusi Bhailo Program", 7000,
                List.of("Patan Durbar Square"), 1));

        executeFestivalPlan(activities);
    }
}
