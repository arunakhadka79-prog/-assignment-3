public class TikaCeremony extends FestivalActivity {

    int expectedGuests;
    String mainFamilyElder;

    public TikaCeremony(String activityName, double estimatedCost, int expectedGuests, String mainFamilyElder) {
        super("Tika Ceremony", estimatedCost);
        this.expectedGuests = expectedGuests;
        this.mainFamilyElder = mainFamilyElder;
    }

    @Override
    public void planActivity() throws FestivalPlanningException {
        if (expectedGuests < 5) {
            throw new InvalidGuestCountException("Not enough guests for a lively Tika! Is everyone on vacation?");
        }
        if (estimatedCost > 50000) {
            throw new BudgetExceededException("Tika budget too high! Is this for the whole village?");
        }
        System.out.println("Tika ceremony with " + mainFamilyElder + " planned successfully for "
                + expectedGuests + " guests!");
    }

    public static void main(String[] args) {
        TikaCeremony validCeremony = new TikaCeremony("Tika Ceremony", 25000, 15, "Grandfather Hari");
        TikaCeremony tooFewGuests = new TikaCeremony("Tika Ceremony", 20000, 2, "Aunt Sita");
        TikaCeremony tooExpensive = new TikaCeremony("Tika Ceremony", 75000, 20, "Uncle Bishnu");

        TikaCeremony[] ceremonies = { validCeremony, tooFewGuests, tooExpensive };

        for (TikaCeremony ceremony : ceremonies) {
            ceremony.displayOverview();
            try {
                ceremony.planActivity();
            } catch (InvalidGuestCountException e) {
                System.out.println("Caught InvalidGuestCountException: " + e.getMessage());
            } catch (BudgetExceededException e) {
                System.out.println("Caught BudgetExceededException: " + e.getMessage());
            } catch (FestivalPlanningException e) {
                System.out.println("Caught general FestivalPlanningException: " + e.getMessage());
            }
            System.out.println("---");
        }
    }
}
