import java.util.List;

public class DeusiBhailo extends FestivalActivity {

    List<String> plannedRoutes;
    int numberOfPerformers;

    public DeusiBhailo(String activityName, double estimatedCost, List<String> plannedRoutes, int numberOfPerformers) {
        super("Deusi Bhailo Program", estimatedCost);
        this.plannedRoutes = plannedRoutes;
        this.numberOfPerformers = numberOfPerformers;
    }

    @Override
    public void planActivity() throws FestivalPlanningException {
        if (plannedRoutes == null || plannedRoutes.isEmpty()) {
            throw new NoRouteException("No routes planned for Deusi Bhailo! Are we just singing in the living room?");
        }
        if (numberOfPerformers < 3) {
            throw new FestivalPlanningException("Need at least 3 performers for a proper Deusi Bhailo!");
        }
        System.out.println("Deusi Bhailo program with " + numberOfPerformers + " performers planned for "
                + plannedRoutes.size() + " routes!");
    }

    public static void main(String[] args) {
        DeusiBhailo validProgram = new DeusiBhailo("Deusi Bhailo Program", 15000,
                List.of("Baneshwor Lane", "New Road", "Putalisadak"), 6);

        DeusiBhailo noRoutes = new DeusiBhailo("Deusi Bhailo Program", 10000, List.of(), 5);

        DeusiBhailo tooFewPerformers = new DeusiBhailo("Deusi Bhailo Program", 8000,
                List.of("Lazimpat Street"), 2);

        DeusiBhailo[] programs = { validProgram, noRoutes, tooFewPerformers };

        for (DeusiBhailo program : programs) {
            program.displayOverview();
            try {
                program.planActivity();
            } catch (NoRouteException e) {
                System.out.println("Caught NoRouteException: " + e.getMessage());
            } catch (FestivalPlanningException e) {
                System.out.println("Caught general FestivalPlanningException: " + e.getMessage());
            }
            System.out.println("---");
        }
    }
}
