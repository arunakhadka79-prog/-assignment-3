public class StudentDashboard {

    public void displayCourseStatus(String studentId, String courseId, EligibilityRule rule) {
        System.out.println("Checking enrollment status for " + studentId + " in " + courseId + "...");
        try {
            boolean eligible = rule.isEligible(studentId, courseId);
            if (eligible) {
                System.out.println(" You are enrolled! Access course materials now.");
            } else {
                System.out.println(" You are not currently eligible for this course.");
            }
        } catch (EnrollmentDeniedException e) {
            System.out.println(" Enrollment denied: " + e.getMessage() + ". Please contact support.");
        } finally {
            System.out.println("Status check completed for " + studentId + ".");
        }
    }

    public static void main(String[] args) {
        StudentDashboard dashboard = new StudentDashboard();
        EligibilityRule rule = CourseEnrollmentManager.SKILL_NEPAL_RULE;

        dashboard.displayCourseStatus("SKILL123", "JAVA101", rule);
        System.out.println("---");
        dashboard.displayCourseStatus("SKILL999", "PYTHON202", rule);
        System.out.println("---");
        dashboard.displayCourseStatus("STUDENT001", "JAVA101", rule);
        System.out.println("---");
    }
}
