public class CourseEnrollmentManager {

    // keeping this as a static field so StudentDashboard can reuse the same rule
    public static final EligibilityRule SKILL_NEPAL_RULE = (studentId, courseId) -> {
        if (studentId.equals("SKILL999")) {
            throw new EnrollmentDeniedException("Student account suspended due to outstanding fees, Roshan!");
        }
        if (courseId.equals("JAVA101") && !studentId.startsWith("SKILL")) {
            throw new EnrollmentDeniedException("Invalid student ID format. Please use 'SKILL' prefix, Anisha!");
        }
        if (studentId.startsWith("SKILL") && courseId.equals("JAVA101")) {
            return true;
        }
        return false;
    };

    public static void enrollStudent(String studentId, String courseId, EligibilityRule rule) {
        System.out.println("Attempting to enroll " + studentId + " in " + courseId + "...");
        try {
            boolean eligible = rule.isEligible(studentId, courseId);
            if (eligible) {
                System.out.println("Enrollment successful for " + studentId + " in " + courseId
                        + "! Happy learning!");
            } else {
                System.out.println("Enrollment failed for " + studentId + ": Not eligible for this course.");
            }
        } catch (EnrollmentDeniedException e) {
            System.out.println("Enrollment failed for " + studentId + ": " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        EligibilityRule skillNepalRule = SKILL_NEPAL_RULE;

        enrollStudent("SKILL123", "JAVA101", skillNepalRule);
        System.out.println("---");
        enrollStudent("SKILL999", "JAVA101", skillNepalRule);
        System.out.println("---");
        enrollStudent("STUDENT001", "JAVA101", skillNepalRule);
        System.out.println("---");
        enrollStudent("SKILL123", "PYTHON202", skillNepalRule);
        System.out.println("---");
    }
}
