public class KathmanduTrafficValidator implements RouteValidator {

    @Override
    public boolean isValidCommuteRoute(String origin, String destination, double distanceKm)
            throws InvalidRouteException {
        if (origin.equalsIgnoreCase(destination)) {
            throw new SameLocationException(
                    "Origin and destination cannot be the same! Are you just spinning in circles, Damodar?");
        }
        if (distanceKm < 0.1 || distanceKm > 30) {
            throw new InvalidRouteException("Distance " + distanceKm + "km is unrealistic for Kathmandu commute!");
        }
        return true;
    }

    public static void main(String[] args) {
        KathmanduTrafficValidator validator = new KathmanduTrafficValidator();

        Object[][] testCases = {
                { "Baneshwor", "Baneshwor", 2.0 },
                { "Thamel", "Patan", 5.5 },
                { "Kalanki", "Balaju", 0.05 },
                { "Bhaktapur", "Nagarkot", 35.0 }
        };

        for (Object[] testCase : testCases) {
            String origin = (String) testCase[0];
            String destination = (String) testCase[1];
            double distance = (Double) testCase[2];

            System.out.println("Checking route: " + origin + " -> " + destination + " (" + distance + "km)");
            try {
                boolean valid = validator.isValidCommuteRoute(origin, destination, distance);
                System.out.println("Route is valid: " + valid);
            } catch (SameLocationException e) {
                System.out.println("Caught SameLocationException: " + e.getMessage());
            } catch (InvalidRouteException e) {
                System.out.println("Caught InvalidRouteException: " + e.getMessage());
            }
            System.out.println("---");
        }
    }
}
