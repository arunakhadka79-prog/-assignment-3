import java.util.List;

public class AirportArrivalsDataSource extends TouristDataSource {

    public AirportArrivalsDataSource() {
        super("Tribhuvan Airport Arrivals");
    }

    @Override
    public List<String> fetchData() throws DataSourceAccessException {
        if (sourceName.contains("Tribhuvan") && Math.random() < 0.3) {
            ConnectionLostException cause = new ConnectionLostException(
                    "Airport data connection lost! Maybe a pigeon sat on the antenna?");
            throw new DataSourceAccessException("Failed to fetch data from " + sourceName, cause);
        }
        return List.of("Visitor: John Doe, USA", "Visitor: Emily White, UK");
    }

    public static void main(String[] args) {
        AirportArrivalsDataSource source = new AirportArrivalsDataSource();

        for (int i = 1; i <= 5; i++) {
            System.out.println("Attempt " + i + ":");
            try {
                List<String> data = source.fetchData();
                System.out.println("Fetched data: " + data);
            } catch (DataSourceAccessException e) {
                System.out.println("Caught DataSourceAccessException: " + e.getMessage());
                if (e.getCause() != null) {
                    System.out.println("  Caused by: " + e.getCause().getClass().getSimpleName()
                            + " - " + e.getCause().getMessage());
                }
            }
            System.out.println("---");
        }
    }
}
