import java.util.List;

public class HotelRegistrationsDataSource extends TouristDataSource {

    public HotelRegistrationsDataSource() {
        super("Kathmandu Hotels Registrations");
    }

    @Override
    public List<String> fetchData() throws DataSourceAccessException {
        if (sourceName.contains("Hotels") && Math.random() < 0.2) {
            AuthenticationFailedException cause = new AuthenticationFailedException(
                    "Hotel API authentication failed! Did someone forget the password again?");
            throw new DataSourceAccessException("Failed to fetch data from " + sourceName, cause);
        }
        return List.of("Hotel: Yak & Yeti, Guest: Ram Thapa, NP", "Hotel: Annapurna, Guest: Alice Smith, AU");
    }

    public static void main(String[] args) {
        HotelRegistrationsDataSource source = new HotelRegistrationsDataSource();

        for (int i = 1; i <= 5; i++) {
            System.out.println("Attempt " + i + ":");
            try {
                List<String> data = source.fetchData();
                System.out.println("Fetched data: " + data);
            } catch (DataSourceAccessException e) {
                System.out.println("Caught DataSourceAccessException: " + e.getMessage());
                if (e.getCause() != null) {
                    System.out.println("  Caused by: " + e.getCause().getClass().getSimpleName()
                            + " - " + e.getCause().getMessage());
                }
            }
            System.out.println("---");
        }
    }
}
