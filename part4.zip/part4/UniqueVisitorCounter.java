import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class UniqueVisitorCounter implements DataProcessor {

    @Override
    public List<String> process(List<String> rawData) throws DataProcessingException {
        if (rawData == null || rawData.isEmpty()) {
            throw new EmptyDataException("No raw data to process! Did all tourists go missing?");
        }

        Set<String> uniqueNames = new HashSet<>();
        for (String entry : rawData) {
            String name = extractName(entry);
            if (name != null) {
                uniqueNames.add(name);
            }
        }

        return List.of("Unique Visitors: " + uniqueNames.size());
    }

    // pulls the name out of "Visitor: Name, Country" or "Guest: Name, Country"
    private String extractName(String entry) {
        if (entry == null) {
            return null;
        }
        int colonIndex = entry.indexOf(':');
        if (colonIndex == -1) {
            return null;
        }
        String afterColon = entry.substring(colonIndex + 1).trim();
        int commaIndex = afterColon.indexOf(',');
        String name = (commaIndex == -1) ? afterColon : afterColon.substring(0, commaIndex);
        return name.trim();
    }

    public static void main(String[] args) {
        UniqueVisitorCounter counter = new UniqueVisitorCounter();

        System.out.println("Test 1: Empty data list");
        try {
            counter.process(List.of());
        } catch (EmptyDataException e) {
            System.out.println("Caught EmptyDataException: " + e.getMessage());
        } catch (DataProcessingException e) {
            System.out.println("Caught DataProcessingException: " + e.getMessage());
        }

        System.out.println("---");

        System.out.println("Test 2: Dummy data with duplicates");
        List<String> dummyData = List.of(
                "Visitor: John Doe, USA",
                "Visitor: Emily White, UK",
                "Guest: Ram Thapa, NP",
                "Guest: John Doe, USA"
        );
        try {
            List<String> result = counter.process(dummyData);
            System.out.println("Processed result: " + result);
        } catch (DataProcessingException e) {
            System.out.println("Caught DataProcessingException: " + e.getMessage());
        }
    }
}
